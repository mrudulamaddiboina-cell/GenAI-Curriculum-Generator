import React from "react";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";

const toneLabels = {
  fair: "Fair",
  medium: "Medium",
  olive: "Olive",
  deep: "Deep",
};

export default function SkinToneResult({ analysis }) {
  const { skin_tone_category, skin_tone_hex, skin_tone_rgb, undertone, analysis_explanation } = analysis;

  return (
    <motion.div
      className="vibrant-card rounded-3xl p-7 sm:p-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="flex items-start gap-6">
        {/* Swatch */}
        <div className="flex-shrink-0">
          <div
            className="w-20 h-20 rounded-2xl shadow-lg ring-4 ring-white"
            style={{ backgroundColor: skin_tone_hex || "#D4A574" }}
          />
          {skin_tone_hex && (
            <p className="font-body text-[10px] text-gray-400 text-center mt-2">{skin_tone_hex}</p>
          )}
        </div>

        {/* Info */}
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-7 h-7 rounded-xl shimmer-bg flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5 text-white" />
            </div>
            <p className="font-body text-xs text-gray-400 uppercase tracking-widest">Skin Analysis</p>
          </div>

          <h3 className="font-display text-2xl font-bold text-[#0C0C12] mb-1">
            {toneLabels[skin_tone_category] || skin_tone_category} Skin Tone
          </h3>

          <div className="flex flex-wrap gap-2 mb-4">
            {undertone && (
              <span className="font-body text-xs font-medium px-3 py-1 rounded-full capitalize"
                style={{
                  backgroundColor: undertone === "warm" ? "#FFF3E0" : undertone === "cool" ? "#EDE7F6" : "#F3F4F6",
                  color: undertone === "warm" ? "#E65100" : undertone === "cool" ? "#4527A0" : "#374151",
                }}>
                {undertone} undertone
              </span>
            )}
            {skin_tone_rgb && (
              <span className="font-body text-xs font-medium px-3 py-1 rounded-full bg-gray-100 text-gray-500">
                RGB: {skin_tone_rgb}
              </span>
            )}
          </div>

          {analysis_explanation && (
            <p className="font-body text-sm text-gray-500 leading-relaxed">{analysis_explanation}</p>
          )}
        </div>
      </div>
    </motion.div>
  );
}