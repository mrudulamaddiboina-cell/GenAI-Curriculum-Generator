import React from "react";
import { motion } from "framer-motion";
import { Scissors } from "lucide-react";

export default function HairstyleSection({ hairstyles }) {
  if (!hairstyles?.length) return null;

  return (
    <motion.div
      className="vibrant-card rounded-3xl p-7 sm:p-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
    >
      <div className="flex items-center gap-2 mb-6">
        <div className="w-7 h-7 rounded-xl shimmer-bg flex items-center justify-center">
          <Scissors className="w-3.5 h-3.5 text-white" />
        </div>
        <p className="font-body text-xs text-gray-400 uppercase tracking-widest">Hairstyles</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {hairstyles.map((style, i) => (
          <motion.div
            key={i}
            className="bg-gray-50 hover:bg-white border border-gray-100 hover:border-pink-100 rounded-2xl p-4 transition-all hover:shadow-sm"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 + i * 0.06 }}
            whileHover={{ x: 3 }}
          >
            <div className="flex items-start gap-3">
              <span className="text-xl mt-0.5">✂️</span>
              <div>
                <p className="font-display text-sm font-semibold text-[#0C0C12]">{style.name}</p>
                {style.description && (
                  <p className="font-body text-xs text-gray-400 mt-0.5 leading-snug">{style.description}</p>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}