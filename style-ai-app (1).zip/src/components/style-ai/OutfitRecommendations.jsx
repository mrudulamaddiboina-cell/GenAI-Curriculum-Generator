import React from "react";
import { motion } from "framer-motion";
import { Shirt, Briefcase, Coffee, Star } from "lucide-react";

const categoryIcons = {
  formal: Briefcase,
  business: Briefcase,
  casual: Coffee,
  party: Star,
  default: Shirt,
};

const categoryColors = {
  formal: { bg: "#EDE7F6", text: "#4527A0", dot: "#7B4FD4" },
  business: { bg: "#E3F2FD", text: "#0D47A1", dot: "#4361EE" },
  casual: { bg: "#E8F5E9", text: "#1B5E20", dot: "#00D4AA" },
  party: { bg: "#FCE4EC", text: "#880E4F", dot: "#FF3CAC" },
  default: { bg: "#F3F4F6", text: "#374151", dot: "#9CA3AF" },
};

export default function OutfitRecommendations({ outfits }) {
  if (!outfits?.length) return null;

  const grouped = outfits.reduce((acc, o) => {
    const cat = (o.category || "casual").toLowerCase();
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(o);
    return acc;
  }, {});

  return (
    <motion.div
      className="vibrant-card rounded-3xl p-7 sm:p-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
    >
      <div className="flex items-center gap-2 mb-6">
        <div className="w-7 h-7 rounded-xl shimmer-bg flex items-center justify-center">
          <Shirt className="w-3.5 h-3.5 text-white" />
        </div>
        <p className="font-body text-xs text-gray-400 uppercase tracking-widest">Outfit Recommendations</p>
      </div>

      <div className="space-y-6">
        {Object.entries(grouped).map(([category, items]) => {
          const Icon = categoryIcons[category] || categoryIcons.default;
          const colors = categoryColors[category] || categoryColors.default;
          return (
            <div key={category}>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: colors.dot }} />
                <p className="font-display text-sm font-semibold capitalize text-gray-700">{category}</p>
                <span className="text-xs font-body px-2 py-0.5 rounded-full" style={{ backgroundColor: colors.bg, color: colors.text }}>
                  {items.length} items
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {items.map((item, i) => (
                  <motion.div
                    key={i}
                    className="bg-gray-50 hover:bg-white rounded-2xl px-4 py-3.5 border border-gray-100 hover:border-gray-200 hover:shadow-sm transition-all cursor-default"
                    whileHover={{ x: 3 }}
                  >
                    <p className="font-display text-sm font-semibold text-[#0C0C12] mb-0.5">{item.name}</p>
                    {item.description && (
                      <p className="font-body text-xs text-gray-400 leading-snug">{item.description}</p>
                    )}
                    {item.type && (
                      <span className="inline-block mt-1.5 font-body text-[10px] uppercase tracking-wider text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">
                        {item.type}
                      </span>
                    )}
                  </motion.div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}