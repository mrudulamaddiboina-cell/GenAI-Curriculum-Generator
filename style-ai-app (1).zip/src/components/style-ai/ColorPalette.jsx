import React from "react";
import { motion } from "framer-motion";
import { Palette } from "lucide-react";

export default function ColorPalette({ colors }) {
  if (!colors?.length) return null;

  const grouped = colors.reduce((acc, c) => {
    const type = c.type || "primary";
    if (!acc[type]) acc[type] = [];
    acc[type].push(c);
    return acc;
  }, {});

  return (
    <motion.div
      className="vibrant-card rounded-3xl p-7 sm:p-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
    >
      <div className="flex items-center gap-2 mb-6">
        <div className="w-7 h-7 rounded-xl shimmer-bg flex items-center justify-center">
          <Palette className="w-3.5 h-3.5 text-white" />
        </div>
        <p className="font-body text-xs text-gray-400 uppercase tracking-widest">Your Color Palette</p>
      </div>

      <div className="space-y-5">
        {Object.entries(grouped).map(([type, cols]) => (
          <div key={type}>
            <p className="font-display text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 capitalize">{type}</p>
            <div className="flex flex-wrap gap-3">
              {cols.map((c, i) => (
                <motion.div
                  key={i}
                  className="group flex flex-col items-center gap-1.5"
                  whileHover={{ y: -4 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div
                    className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl shadow-md ring-2 ring-white/80 cursor-pointer transition-all group-hover:ring-4 group-hover:shadow-xl"
                    style={{ backgroundColor: c.hex }}
                    title={c.name}
                  />
                  <p className="font-body text-[10px] text-gray-400 text-center max-w-[56px] leading-tight">{c.name}</p>
                </motion.div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}