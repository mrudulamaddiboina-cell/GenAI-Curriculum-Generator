import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Upload, Camera, Sparkles, User, Users, CheckCircle2 } from "lucide-react";

export default function UploadPortal({ onAnalysisStart }) {
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState(null);
  const [gender, setGender] = useState("female");
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const fileRef = useRef(null);

  const handleFile = (file) => {
    if (!file || !file.type.startsWith("image/")) return;
    setImage(file);
    const reader = new FileReader();
    reader.onload = (e) => setPreview(e.target.result);
    reader.readAsDataURL(file);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    handleFile(e.dataTransfer.files[0]);
  };

  const handleAnalyze = async () => {
    if (!image) return;
    setUploading(true);
    setProgress(30);
    const interval = setInterval(() => setProgress(p => Math.min(p + 10, 90)), 300);
    const { file_url } = await base44.integrations.Core.UploadFile({ file: image });
    clearInterval(interval);
    setProgress(100);
    await new Promise(r => setTimeout(r, 400));
    onAnalysisStart({ photoUrl: file_url, gender });
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="vibrant-card rounded-3xl p-8 sm:p-10">
        {/* Upload zone */}
        <div
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => !preview && fileRef.current?.click()}
          className={`relative rounded-2xl border-2 border-dashed transition-all duration-300 overflow-hidden cursor-pointer mb-6 ${
            isDragging
              ? "border-purple-400 bg-purple-50"
              : preview
              ? "border-transparent"
              : "border-gray-200 hover:border-purple-300 bg-gray-50 hover:bg-purple-50/30"
          }`}
          style={{ minHeight: 240 }}
        >
          {preview ? (
            <div className="relative h-60">
              <img src={preview} alt="Preview" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
              <button
                onClick={(e) => { e.stopPropagation(); setPreview(null); setImage(null); }}
                className="absolute top-3 right-3 bg-white/90 backdrop-blur text-gray-700 text-xs px-3 py-1.5 rounded-xl font-body font-medium hover:bg-white transition-all"
              >
                Change
              </button>
              <div className="absolute bottom-4 left-4">
                <div className="flex items-center gap-2 bg-white/90 backdrop-blur rounded-xl px-3 py-2">
                  <div className="w-2 h-2 rounded-full bg-green-400" />
                  <span className="font-body text-xs font-medium text-gray-700">Photo ready</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-14 px-6 text-center">
              <motion.div
                className="w-16 h-16 rounded-2xl shimmer-bg flex items-center justify-center mb-4"
                animate={isDragging ? { scale: 1.1 } : { scale: 1 }}
              >
                {isDragging ? <Camera className="w-7 h-7 text-white" /> : <Upload className="w-7 h-7 text-white" />}
              </motion.div>
              <p className="font-display font-semibold text-gray-700 mb-1">
                {isDragging ? "Drop it here!" : "Upload your photo"}
              </p>
              <p className="font-body text-sm text-gray-400">
                Drag & drop or click to browse · JPG, PNG, WEBP
              </p>
            </div>
          )}
        </div>

        <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => handleFile(e.target.files[0])} />

        {/* Gender */}
        <div className="mb-6">
          <p className="font-display text-sm font-semibold text-gray-700 mb-3">Style for</p>
          <div className="grid grid-cols-2 gap-3">
            {[
              { val: "female", label: "Women", icon: User },
              { val: "male", label: "Men", icon: Users },
            ].map(({ val, label, icon: Icon }) => (
              <button
                key={val}
                onClick={() => setGender(val)}
                className={`relative flex items-center justify-center gap-3 py-4 rounded-2xl font-display text-base font-bold border-3 transition-all duration-300 ${
                  gender === val
                    ? "border-purple-500 text-purple-700 bg-purple-50 shadow-[0_4px_20px_rgba(123,79,212,0.25)] scale-105"
                    : "border-gray-200 text-gray-400 bg-white hover:border-purple-200 hover:text-gray-600"
                }`}
              >
                <Icon className={`w-5 h-5 ${gender === val ? "text-purple-600" : "text-gray-400"}`} />
                {label}
                {gender === val && (
                  <CheckCircle2 className="w-5 h-5 text-purple-500 absolute top-2 right-2" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Progress */}
        <AnimatePresence>
          {uploading && progress < 100 && (
            <motion.div className="mb-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <motion.div
                  className="h-full shimmer-bg rounded-full"
                  initial={{ width: "0%" }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.4 }}
                />
              </div>
              <p className="font-body text-xs text-gray-400 mt-2 text-center">Uploading photo...</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* CTA */}
        <button
          onClick={handleAnalyze}
          disabled={!image || uploading}
          className={`w-full py-4 rounded-2xl font-display font-bold text-base flex items-center justify-center gap-2 transition-all duration-300 ${
            image && !uploading
              ? "bg-purple-600 hover:bg-purple-700 text-white shadow-[0_8px_30px_rgba(123,79,212,0.4)] scale-[1.02]"
              : "bg-gray-100 text-gray-400 cursor-not-allowed"
          }`}
        >
          <Sparkles className="w-4 h-4" />
          {uploading ? "Analyzing..." : "Analyze My Style"}
        </button>

        <p className="font-body text-xs text-gray-400 text-center mt-3">
          Your photo is processed securely and never shared.
        </p>
      </div>
    </div>
  );
}