import React from "react";
import { motion } from "framer-motion";
import { Upload, Cpu, Palette, ShoppingBag } from "lucide-react";

const steps = [
  { icon: Upload, step: "01", title: "Upload Your Photo", desc: "Take or upload a clear facial photo. No makeup or filter needed — just you.", color: "#FF3CAC" },
  { icon: Cpu, step: "02", title: "AI Analyzes", desc: "Our AI scans your skin tone, undertone, and facial features in seconds.", color: "#7B4FD4" },
  { icon: Palette, step: "03", title: "Get Your Profile", desc: "Receive your full style profile: colors, outfits, hairstyles & accessories.", color: "#4361EE" },
  { icon: ShoppingBag, step: "04", title: "Shop the Look", desc: "Browse curated items handpicked for your unique profile from top brands.", color: "#00D4AA" },
];

export default function HowItWorks() {
  return (
    <section className="py-24 px-6 relative overflow-hidden" style={{ backgroundColor: "#0C0C12" }}>
      {/* Background blobs */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute w-96 h-96 rounded-full opacity-10 blob"
          style={{ background: "#FF3CAC", filter: "blur(120px)", top: "-5%", right: "0%" }} />
        <div className="absolute w-80 h-80 rounded-full opacity-10 blob-delay"
          style={{ background: "#4361EE", filter: "blur(100px)", bottom: "0%", left: "0%" }} />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <span className="inline-block font-body text-xs font-semibold tracking-widest uppercase text-purple-400 bg-purple-900/30 px-4 py-1.5 rounded-full mb-4">
            How It Works
          </span>
          <h2 className="font-display text-4xl sm:text-5xl font-bold text-white leading-tight">
            From photo to <span className="gradient-text">styled</span> in 60 seconds
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((s, i) => (
            <motion.div
              key={s.step}
              className="relative group"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.12 }}
            >
              <div className="bg-white/5 hover:bg-white/8 border border-white/10 rounded-3xl p-7 h-full transition-all duration-300 hover:border-white/20 hover:shadow-[0_8px_40px_rgba(255,255,255,0.05)]">
                {/* Step number */}
                <p className="font-display text-6xl font-bold text-white/5 mb-3 leading-none">{s.step}</p>
                {/* Icon */}
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-5"
                  style={{ backgroundColor: s.color + "25", border: `1px solid ${s.color}40` }}>
                  <s.icon className="w-5 h-5" style={{ color: s.color }} />
                </div>
                <h3 className="font-display text-white font-bold text-lg mb-2">{s.title}</h3>
                <p className="font-body text-gray-400 text-sm leading-relaxed">{s.desc}</p>
              </div>

              {/* Connector line (not last) */}
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-3 w-6 h-px bg-white/10 z-10" />
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}