import React from "react";
import { motion } from "framer-motion";
import { ScanFace, Palette, ShoppingBag, Sparkles } from "lucide-react";

const features = [
  {
    icon: ScanFace,
    title: "Skin Tone Detection",
    description: "Upload a photo and our AI precisely identifies your skin tone, undertone, and natural pigment profile.",
    gradient: "var(--gradient-card-1)",
    tag: "AI Vision",
  },
  {
    icon: Palette,
    title: "Color Palette Builder",
    description: "Get a personalized palette of colors scientifically matched to flatter your unique complexion.",
    gradient: "var(--gradient-card-2)",
    tag: "Color Science",
  },
  {
    icon: Sparkles,
    title: "Outfit Generator",
    description: "Receive curated outfit suggestions across formal, casual, and evening categories tailored to you.",
    gradient: "var(--gradient-card-3)",
    tag: "Fashion AI",
  },
  {
    icon: ShoppingBag,
    title: "Shop the Look",
    description: "Every recommendation links directly to top Indian retailers like Myntra, Zara, and Amazon.",
    gradient: "var(--gradient-card-4)",
    tag: "Retail Links",
  },
];

export default function FeatureCards() {
  return (
    <section className="py-24 px-6 max-w-7xl mx-auto">
      <motion.div
        className="text-center mb-16"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <span className="inline-block font-body text-xs font-semibold tracking-widest uppercase text-purple-500 bg-purple-50 px-4 py-1.5 rounded-full mb-4">
          What We Do
        </span>
        <h2 className="font-display text-4xl sm:text-5xl font-bold text-[#0C0C12] leading-tight">
          Everything you need to<br />
          <span className="gradient-text">look incredible</span>
        </h2>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {features.map((f, i) => (
          <motion.div
            key={f.title}
            className="group relative rounded-3xl overflow-hidden cursor-pointer"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            whileHover={{ y: -6, transition: { duration: 0.3 } }}
          >
            {/* Gradient background */}
            <div className="absolute inset-0 opacity-90 transition-opacity group-hover:opacity-100"
              style={{ background: f.gradient }} />

            <div className="relative z-10 p-7 h-full flex flex-col justify-between min-h-[260px]">
              {/* Top */}
              <div>
                <span className="inline-block font-body text-[10px] font-semibold tracking-widest uppercase text-white/70 bg-white/15 px-3 py-1 rounded-full mb-5">
                  {f.tag}
                </span>
                <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center mb-4">
                  <f.icon className="w-6 h-6 text-white" />
                </div>
              </div>

              {/* Bottom */}
              <div>
                <h3 className="font-display text-white font-bold text-xl mb-2">{f.title}</h3>
                <p className="font-body text-white/75 text-sm leading-relaxed">{f.description}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}