import React from "react";
import { motion } from "framer-motion";
import { ExternalLink, ShoppingBag } from "lucide-react";

const categoryImages = {
  shirt: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&q=80",
  dress: "https://images.unsplash.com/photo-1572804013427-4d7ca7268217?w=400&q=80",
  pants: "https://images.unsplash.com/photo-1594938298603-c8148c4b4357?w=400&q=80",
  shoes: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80",
  watch: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&q=80",
  blazer: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=400&q=80",
  accessory: "https://images.unsplash.com/photo-1589118949245-7d38baf380d6?w=400&q=80",
  default: "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=400&q=80",
};

const retailerColors = {
  Myntra: { bg: "#FF3F6C15", text: "#FF3F6C", border: "#FF3F6C30" },
  Amazon: { bg: "#FF990015", text: "#E47911", border: "#FF990030" },
  Zara: { bg: "#00000010", text: "#000000", border: "#00000020" },
  default: { bg: "#7B4FD415", text: "#7B4FD4", border: "#7B4FD430" },
};

export default function ShopCard({ item, index }) {
  const imgSrc = item.image_url || categoryImages[item.category?.toLowerCase()] || categoryImages.default;
  const rc = retailerColors[item.retailer] || retailerColors.default;

  return (
    <motion.div
      className="group bg-white rounded-3xl overflow-hidden border border-gray-100 hover:border-purple-100 hover:shadow-xl transition-all duration-300 cursor-pointer"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06 }}
      whileHover={{ y: -5 }}
      onClick={() => item.shop_url && window.open(item.shop_url, "_blank")}
    >
      {/* Image */}
      <div className="relative overflow-hidden h-52">
        <img
          src={imgSrc}
          alt={item.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
        {/* Retailer badge */}
        <div
          className="absolute top-3 left-3 font-body text-[10px] font-semibold px-2.5 py-1 rounded-full backdrop-blur-sm border"
          style={{ backgroundColor: rc.bg, color: rc.text, borderColor: rc.border }}
        >
          {item.retailer}
        </div>
        {/* Shop button on hover */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="bg-white/90 backdrop-blur rounded-xl px-4 py-2 flex items-center gap-2 shadow-lg">
            <ShoppingBag className="w-3.5 h-3.5 text-purple-600" />
            <span className="font-display text-xs font-semibold text-purple-600">Shop Now</span>
            <ExternalLink className="w-3 h-3 text-purple-600" />
          </div>
        </div>
      </div>

      {/* Info */}
      <div className="p-4">
        <p className="font-body text-[10px] font-medium text-gray-400 uppercase tracking-wider mb-1">{item.brand}</p>
        <p className="font-display text-sm font-semibold text-[#0C0C12] leading-snug mb-2 line-clamp-2">{item.name}</p>
        <p className="font-display text-base font-bold gradient-text">{item.price}</p>
      </div>
    </motion.div>
  );
}