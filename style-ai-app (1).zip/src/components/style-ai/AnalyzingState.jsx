import React from "react";
import { motion } from "framer-motion";
import { Sparkles, Palette, Shirt, ShoppingBag } from "lucide-react";

const steps = [
  { icon: Sparkles, label: "Detecting skin tone..." },
  { icon: Palette, label: "Building color palette..." },
  { icon: Shirt, label: "Generating outfits..." },
  { icon: ShoppingBag, label: "Curating shopping picks..." },
];

export default function AnalyzingState({ photoUrl }) {
  return (
    <div className="max-w-lg mx-auto text-center py-10">
      {/* Photo orb */}
      <div className="relative flex items-center justify-center mb-10">
        {[80, 120, 160].map((size, i) => (
          <motion.div
            key={size}
            className="absolute rounded-full"
            style={{
              width: size + 60, height: size + 60,
              background: `radial-gradient(circle, ${["#FF3CAC","#7B4FD4","#4361EE"][i]}20, transparent)`,
              border: `1px solid ${["#FF3CAC","#7B4FD4","#4361EE"][i]}30`,
            }}
            animate={{ scale: [1, 1.08, 1], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2 + i * 0.5, repeat: Infinity, ease: "easeInOut", delay: i * 0.3 }}
          />
        ))}
        <div className="relative w-24 h-24 rounded-full overflow-hidden shadow-2xl ring-4 ring-white z-10">
          {photoUrl ? (
            <img src={photoUrl} alt="Analyzing" className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full shimmer-bg" />
          )}
        </div>
      </div>

      <motion.p
        className="font-display text-2xl font-bold text-[#0C0C12] mb-2"
        animate={{ opacity: [0.6, 1, 0.6] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        Analyzing your style...
      </motion.p>
      <p className="font-body text-sm text-gray-400 mb-10">This takes just a few seconds</p>

      {/* Steps */}
      <div className="space-y-3">
        {steps.map((s, i) => (
          <motion.div
            key={s.label}
            className="flex items-center gap-4 vibrant-card rounded-2xl px-5 py-4"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.3 }}
          >
            <div className="w-9 h-9 rounded-xl shimmer-bg flex items-center justify-center flex-shrink-0">
              <s.icon className="w-4 h-4 text-white" />
            </div>
            <span className="font-body text-sm text-gray-600 text-left">{s.label}</span>
            <motion.div
              className="ml-auto flex gap-1"
              animate={{ opacity: [0.3, 1, 0.3] }}
              transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.3 }}
            >
              {[0,1,2].map(d => (
                <div key={d} className="w-1.5 h-1.5 rounded-full shimmer-bg" />
              ))}
            </motion.div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}