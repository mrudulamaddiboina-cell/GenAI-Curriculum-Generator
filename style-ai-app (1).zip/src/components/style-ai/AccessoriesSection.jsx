import React from "react";
import { motion } from "framer-motion";
import { Watch } from "lucide-react";

const emojiMap = {
  watch: "⌚", watches: "⌚",
  necklace: "📿", necklaces: "📿",
  earring: "✨", earrings: "✨",
  bracelet: "🪬", bracelets: "🪬",
  ring: "💍", rings: "💍",
  bag: "👜", bags: "👜",
  belt: "🪢", belts: "🪢",
  hat: "🎩", hats: "🎩",
  sunglasses: "🕶️",
  shoes: "👟",
  default: "💎",
};

export default function AccessoriesSection({ accessories }) {
  if (!accessories?.length) return null;

  return (
    <motion.div
      className="vibrant-card rounded-3xl p-7 sm:p-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      <div className="flex items-center gap-2 mb-6">
        <div className="w-7 h-7 rounded-xl shimmer-bg flex items-center justify-center">
          <Watch className="w-3.5 h-3.5 text-white" />
        </div>
        <p className="font-body text-xs text-gray-400 uppercase tracking-widest">Accessories</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {accessories.map((acc, i) => {
          const emoji = emojiMap[acc.type?.toLowerCase()] || emojiMap.default;
          return (
            <motion.div
              key={i}
              className="bg-gray-50 hover:bg-white border border-gray-100 hover:border-purple-100 rounded-2xl p-4 transition-all hover:shadow-sm"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + i * 0.06 }}
              whileHover={{ x: 3 }}
            >
              <div className="flex items-start gap-3">
                <span className="text-2xl">{emoji}</span>
                <div>
                  <p className="font-display text-sm font-semibold text-[#0C0C12] capitalize">{acc.name || acc.type}</p>
                  {acc.description && (
                    <p className="font-body text-xs text-gray-400 mt-0.5 leading-snug">{acc.description}</p>
                  )}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}