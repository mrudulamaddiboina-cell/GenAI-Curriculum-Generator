import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Sparkles, ArrowRight, Star } from "lucide-react";

const tags = ["#SkinToneAnalysis", "#PersonalStyle", "#AIFashion", "#ColorMatch"];

export default function HeroSection() {
  return (
    <section className="relative min-h-[95vh] flex items-center overflow-hidden" style={{ backgroundColor: "var(--bg)" }}>
      {/* Background blobs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute w-[600px] h-[600px] blob opacity-25"
          style={{ background: "var(--magenta)", filter: "blur(100px)", top: "-10%", right: "-10%" }} />
        <div className="absolute w-[500px] h-[500px] blob-delay opacity-20"
          style={{ background: "var(--electric)", filter: "blur(120px)", bottom: "-10%", left: "-5%" }} />
        <div className="absolute w-[300px] h-[300px] blob opacity-15"
          style={{ background: "var(--mint)", filter: "blur(80px)", top: "40%", left: "30%" }} />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center py-20">
        {/* Left: Text */}
        <div>
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 bg-white rounded-full px-4 py-2 shadow-sm border border-purple-100 mb-6"
          >
            <Star className="w-3.5 h-3.5 text-yellow-400" fill="#FFE566" />
            <span className="font-body text-xs font-medium text-gray-600">AI-Powered Personal Styling</span>
          </motion.div>

          <motion.h1
            className="font-display text-5xl sm:text-6xl lg:text-7xl font-800 leading-[1.05] mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <span className="text-[#0C0C12]">Your Style,</span>
            <br />
            <span className="gradient-text">Reimagined</span>
            <br />
            <span className="text-[#0C0C12]">by AI.</span>
          </motion.h1>

          <motion.p
            className="font-body text-base sm:text-lg text-gray-500 max-w-md mb-8 leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Upload your photo — our AI analyzes your skin tone, undertone, and features to generate
            a complete personalized style playbook.
          </motion.p>

          <motion.div
            className="flex flex-wrap items-center gap-4 mb-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Link to={createPageUrl("StyleAnalysis")}>
              <button className="group flex items-center gap-3 px-7 py-3.5 rounded-2xl font-display font-semibold text-sm text-white bg-purple-600 hover:bg-purple-700 transition-all shadow-[0_4px_20px_rgba(123,79,212,0.4)] hover:shadow-[0_8px_30px_rgba(123,79,212,0.5)]">
                <Sparkles className="w-4 h-4" />
                Analyze My Style
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </Link>
            <Link to={createPageUrl("Shop")}>
              <button className="flex items-center gap-2 px-7 py-3.5 rounded-2xl font-display font-semibold text-sm border-2 border-gray-200 hover:border-purple-300 text-gray-700 hover:text-purple-700 transition-all bg-white">
                Browse Shop
              </button>
            </Link>
          </motion.div>

          {/* Tags */}
          <motion.div
            className="flex flex-wrap gap-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            {tags.map((tag) => (
              <span key={tag} className="font-body text-xs text-gray-400 bg-white/70 px-3 py-1 rounded-full border border-gray-100">
                {tag}
              </span>
            ))}
          </motion.div>
        </div>

        {/* Right: Visual card stack */}
        <motion.div
          className="relative flex items-center justify-center h-[420px] lg:h-[500px]"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {/* Card 3 (back) */}
          <div className="absolute w-56 h-72 rounded-3xl rotate-12 opacity-60 floating"
            style={{ background: "var(--gradient-card-4)", top: "8%", right: "5%" }} />
          {/* Card 2 (mid) */}
          <div className="absolute w-60 h-76 rounded-3xl -rotate-6 opacity-80 blob-delay"
            style={{ background: "var(--gradient-card-2)", top: "12%", left: "10%", height: "76%" }} />
          {/* Card 1 (front) */}
          <div className="relative w-64 h-80 rounded-3xl shadow-2xl overflow-hidden"
            style={{ background: "var(--gradient-card-1)" }}>
            <div className="absolute inset-0 flex flex-col justify-end p-6">
              <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center mb-4">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <p className="font-display text-white font-bold text-xl mb-1">Style Profile</p>
              <p className="font-body text-white/70 text-xs">Warm Skin · Medium Tone</p>
              <div className="flex gap-2 mt-4">
                {["#E8A87C","#C97B52","#8B4513","#D4A574","#F5DEB3"].map(c => (
                  <div key={c} className="w-7 h-7 rounded-full border-2 border-white/30 shadow" style={{ backgroundColor: c }} />
                ))}
              </div>
            </div>
          </div>

          {/* Floating badges */}
          <motion.div
            className="absolute top-4 left-0 bg-white rounded-2xl shadow-lg px-4 py-2.5 flex items-center gap-2"
            animate={{ y: [0, -8, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          >
            <div className="w-2 h-2 rounded-full bg-green-400" />
            <span className="font-body text-xs font-medium text-gray-700">98% Accuracy</span>
          </motion.div>

          <motion.div
            className="absolute bottom-8 right-0 bg-white rounded-2xl shadow-lg px-4 py-2.5"
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          >
            <p className="font-body text-xs font-medium text-gray-700">✨ 10K+ Styles Generated</p>
          </motion.div>
        </motion.div>
      </div>

      {/* Stats bar */}
      <motion.div
        className="absolute bottom-0 left-0 right-0 bg-white/80 backdrop-blur-md border-t border-gray-100 py-5"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
      >
        <div className="max-w-4xl mx-auto px-6 flex flex-wrap justify-center gap-8 sm:gap-16">
          {[
            { val: "10K+", label: "Styles Created" },
            { val: "50+", label: "Fashion Brands" },
            { val: "4", label: "Skin Tone Types" },
            { val: "Free", label: "Always" },
          ].map((s) => (
            <div key={s.label} className="text-center">
              <p className="font-display font-bold text-2xl gradient-text">{s.val}</p>
              <p className="font-body text-xs text-gray-400 mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}