import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { ShoppingBag, ExternalLink, ArrowRight } from "lucide-react";

const categoryColors = {
  shirt: "bg-blue-50 text-blue-600", dress: "bg-pink-50 text-pink-600", pants: "bg-indigo-50 text-indigo-600",
  shoes: "bg-orange-50 text-orange-600", watch: "bg-yellow-50 text-yellow-600", blazer: "bg-gray-100 text-gray-600",
  accessory: "bg-purple-50 text-purple-600", kurta: "bg-rose-50 text-rose-600", saree: "bg-red-50 text-red-600",
  jacket: "bg-cyan-50 text-cyan-600", bag: "bg-lime-50 text-lime-600",
};

export default function CuratedOutfits({ analysis, analysisId }) {
  const { data: outfits = [] } = useQuery({
    queryKey: ["curated-outfits", analysis?.skin_tone_category],
    queryFn: () => base44.entities.Outfit.filter({ is_active: true }, "-created_date"),
    enabled: !!analysis,
  });

  // Filter outfits suitable for the user's skin tone
  const matchedOutfits = outfits.filter(o => {
    if (!o.suitable_for || o.suitable_for.length === 0) return true;
    return o.suitable_for.includes("all") || o.suitable_for.includes(analysis?.skin_tone_category);
  });

  if (matchedOutfits.length === 0) return null;

  return (
    <motion.div
      className="vibrant-card rounded-3xl p-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-purple-600 flex items-center justify-center">
            <ShoppingBag className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="font-display font-bold text-base text-[#0C0C12]">Curated For Your Skin Tone</h3>
            <p className="font-body text-xs text-gray-400 capitalize">{matchedOutfits.length} picks for {analysis?.skin_tone_category} skin</p>
          </div>
        </div>
        <Link to={createPageUrl("Shop") + `?id=${analysisId}`}>
          <button className="flex items-center gap-1 font-display font-semibold text-xs text-purple-600 hover:text-purple-800 transition-colors">
            View All <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </Link>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {matchedOutfits.slice(0, 6).map((outfit, i) => (
          <motion.div
            key={outfit.id}
            className="bg-white rounded-2xl overflow-hidden border border-gray-100 hover:border-purple-200 hover:shadow-md transition-all group"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * i }}
          >
            {outfit.image_url ? (
              <div className="h-28 overflow-hidden bg-gray-50">
                <img src={outfit.image_url} alt={outfit.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
              </div>
            ) : (
              <div className="h-28 bg-gradient-to-br from-purple-50 to-pink-50 flex items-center justify-center">
                <ShoppingBag className="w-8 h-8 text-purple-200" />
              </div>
            )}
            <div className="p-3">
              {outfit.category && (
                <span className={`font-body text-[9px] font-semibold px-2 py-0.5 rounded-full capitalize ${categoryColors[outfit.category] || "bg-gray-50 text-gray-500"}`}>
                  {outfit.category}
                </span>
              )}
              <p className="font-display font-bold text-[11px] text-[#0C0C12] mt-1 leading-snug line-clamp-2">{outfit.name}</p>
              <p className="font-body text-[10px] text-gray-400 mt-0.5">{outfit.brand}</p>
              <div className="flex items-center justify-between mt-1.5">
                <p className="font-display text-xs font-bold text-purple-600">{outfit.price}</p>
                {outfit.shop_url && (
                  <a href={outfit.shop_url} target="_blank" rel="noreferrer" className="text-gray-400 hover:text-purple-500 transition-colors">
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}