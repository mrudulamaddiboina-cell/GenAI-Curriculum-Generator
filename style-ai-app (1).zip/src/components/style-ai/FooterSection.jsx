import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Zap, Instagram, Twitter, Linkedin } from "lucide-react";

export default function FooterSection() {
  return (
    <footer style={{ backgroundColor: "#0C0C12" }} className="border-t border-white/5">
      <div className="max-w-6xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-xl shimmer-bg flex items-center justify-center">
                <Zap className="w-4 h-4 text-white" fill="white" />
              </div>
              <span className="font-display font-bold text-xl text-white">
                <span className="gradient-text">Style</span>AI
              </span>
            </div>
            <p className="font-body text-gray-400 text-sm max-w-xs leading-relaxed">
              AI-powered personal styling that analyzes your skin tone and crafts a complete style playbook — totally free.
            </p>
            <div className="flex gap-3 mt-5">
              {[Instagram, Twitter, Linkedin].map((Icon, i) => (
                <div key={i} className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center cursor-pointer transition-all">
                  <Icon className="w-4 h-4 text-gray-400" />
                </div>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <p className="font-display text-white font-semibold text-sm mb-4">Product</p>
            <div className="space-y-2.5">
              {[
                { name: "Style Analysis", page: "StyleAnalysis" },
                { name: "Shop", page: "Shop" },
                { name: "Recommendations", page: "Recommendations" },
              ].map(l => (
                <Link key={l.name} to={createPageUrl(l.page)} className="block font-body text-sm text-gray-400 hover:text-white transition-colors">
                  {l.name}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <p className="font-display text-white font-semibold text-sm mb-4">Company</p>
            <div className="space-y-2.5">
              {[
                { name: "About", page: "About" },
                { name: "Home", page: "Home" },
              ].map(l => (
                <Link key={l.name} to={createPageUrl(l.page)} className="block font-body text-sm text-gray-400 hover:text-white transition-colors">
                  {l.name}
                </Link>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-white/5 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-body text-xs text-gray-600">© 2026 StyleAI. All rights reserved.</p>
          <p className="font-body text-xs text-gray-600">Made with <span className="gradient-text font-semibold">AI</span> for fashion lovers</p>
        </div>
      </div>
    </footer>
  );
}