import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { X } from "lucide-react";

const defaultBrand = { name: "", description: "", website: "", category: "mid-range", retailer: "Myntra", is_active: true };

export default function BrandForm({ brand, onClose, onSaved }) {
  const [form, setForm] = useState(brand || defaultBrand);
  const [saving, setSaving] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    if (brand?.id) {
      await base44.entities.Brand.update(brand.id, form);
    } else {
      await base44.entities.Brand.create(form);
    }
    setSaving(false);
    onSaved();
  };

  return (
    <div className="vibrant-card rounded-2xl p-6 mb-6 border-2 border-purple-100">
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-display font-bold text-sm text-[#0C0C12]">{brand ? "Edit Brand" : "New Brand"}</h3>
        <button onClick={onClose} className="w-7 h-7 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center">
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
      <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="sm:col-span-2">
          <label className="font-body text-xs font-medium text-gray-500 mb-1 block">Brand Name *</label>
          <input required value={form.name} onChange={e => set("name", e.target.value)} placeholder="e.g. Zara" className="w-full px-4 py-2.5 rounded-xl border border-gray-200 font-body text-sm focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100" />
        </div>
        <div className="sm:col-span-2">
          <label className="font-body text-xs font-medium text-gray-500 mb-1 block">Description</label>
          <textarea value={form.description} onChange={e => set("description", e.target.value)} rows={2} placeholder="About the brand..." className="w-full px-4 py-2.5 rounded-xl border border-gray-200 font-body text-sm focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100 resize-none" />
        </div>
        <div>
          <label className="font-body text-xs font-medium text-gray-500 mb-1 block">Category</label>
          <select value={form.category} onChange={e => set("category", e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 font-body text-sm focus:outline-none focus:border-purple-400">
            {["luxury","premium","mid-range","budget"].map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label className="font-body text-xs font-medium text-gray-500 mb-1 block">Retailer</label>
          <select value={form.retailer} onChange={e => set("retailer", e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 font-body text-sm focus:outline-none focus:border-purple-400">
            {["Amazon","Myntra","Zara","Ajio","Nykaa Fashion","Other"].map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="font-body text-xs font-medium text-gray-500 mb-1 block">Website</label>
          <input type="url" value={form.website} onChange={e => set("website", e.target.value)} placeholder="https://..." className="w-full px-4 py-2.5 rounded-xl border border-gray-200 font-body text-sm focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100" />
        </div>
        <div className="sm:col-span-2 flex items-center gap-3">
          <input type="checkbox" id="active-brand" checked={form.is_active} onChange={e => set("is_active", e.target.checked)} className="w-4 h-4 accent-purple-500" />
          <label htmlFor="active-brand" className="font-body text-xs text-gray-500">Active (visible in shop)</label>
        </div>
        <div className="sm:col-span-2 flex gap-3 justify-end pt-2">
          <button type="button" onClick={onClose} className="px-5 py-2.5 rounded-xl font-display text-xs font-semibold border border-gray-200 text-gray-500 hover:bg-gray-50">Cancel</button>
          <button type="submit" disabled={saving} className="px-6 py-2.5 rounded-xl font-display text-xs font-semibold text-white shimmer-bg hover:opacity-90 disabled:opacity-60">
            {saving ? "Saving..." : brand ? "Save Changes" : "Add Brand"}
          </button>
        </div>
      </form>
    </div>
  );
}