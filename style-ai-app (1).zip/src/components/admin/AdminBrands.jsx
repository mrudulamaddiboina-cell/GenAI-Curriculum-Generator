import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, Globe, ToggleLeft, ToggleRight } from "lucide-react";
import BrandForm from "./BrandForm";

export default function AdminBrands() {
  const qc = useQueryClient();
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);

  const { data: brands = [], isLoading } = useQuery({
    queryKey: ["brands"],
    queryFn: () => base44.entities.Brand.list("-created_date"),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Brand.delete(id),
    onSuccess: () => qc.invalidateQueries(["brands"]),
  });

  const toggleMutation = useMutation({
    mutationFn: ({ id, is_active }) => base44.entities.Brand.update(id, { is_active }),
    onSuccess: () => qc.invalidateQueries(["brands"]),
  });

  const tierColors = { luxury: "bg-yellow-50 text-yellow-700 border-yellow-200", premium: "bg-purple-50 text-purple-700 border-purple-200", "mid-range": "bg-blue-50 text-blue-700 border-blue-200", budget: "bg-green-50 text-green-700 border-green-200" };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="font-display text-xl font-bold text-[#0C0C12]">Brands</h2>
          <p className="font-body text-xs text-gray-400 mt-0.5">{brands.length} brands in collection</p>
        </div>
        <button
          onClick={() => { setEditing(null); setShowForm(true); }}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-display font-semibold text-xs text-white shimmer-bg hover:opacity-90 transition-all"
        >
          <Plus className="w-3.5 h-3.5" /> Add Brand
        </button>
      </div>

      {showForm && (
        <BrandForm
          brand={editing}
          onClose={() => { setShowForm(false); setEditing(null); }}
          onSaved={() => { setShowForm(false); setEditing(null); qc.invalidateQueries(["brands"]); }}
        />
      )}

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[1,2,3,4].map(i => <div key={i} className="h-24 bg-gray-100 rounded-2xl animate-pulse" />)}
        </div>
      ) : brands.length === 0 ? (
        <div className="text-center py-16">
          <p className="font-body text-sm text-gray-400">No brands yet. Add your first brand!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {brands.map(brand => (
            <div key={brand.id} className={`vibrant-card rounded-2xl p-5 flex items-start justify-between gap-3 transition-all ${!brand.is_active ? "opacity-50" : ""}`}>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <p className="font-display font-bold text-sm text-[#0C0C12]">{brand.name}</p>
                  {brand.category && (
                    <span className={`font-body text-[10px] font-semibold px-2 py-0.5 rounded-full border capitalize ${tierColors[brand.category] || "bg-gray-50 text-gray-500 border-gray-200"}`}>
                      {brand.category}
                    </span>
                  )}
                </div>
                {brand.description && <p className="font-body text-xs text-gray-400 leading-snug mb-2 line-clamp-2">{brand.description}</p>}
                <div className="flex items-center gap-3">
                  {brand.retailer && <span className="font-body text-[10px] text-gray-400">{brand.retailer}</span>}
                  {brand.website && (
                    <a href={brand.website} target="_blank" rel="noreferrer" className="flex items-center gap-1 font-body text-[10px] text-purple-500 hover:underline">
                      <Globe className="w-3 h-3" /> Website
                    </a>
                  )}
                </div>
              </div>
              <div className="flex flex-col items-center gap-2">
                <button onClick={() => { setEditing(brand); setShowForm(true); }} className="w-8 h-8 rounded-xl bg-gray-50 hover:bg-purple-50 hover:text-purple-600 flex items-center justify-center transition-all">
                  <Pencil className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => toggleMutation.mutate({ id: brand.id, is_active: !brand.is_active })} className="w-8 h-8 rounded-xl bg-gray-50 flex items-center justify-center transition-all">
                  {brand.is_active ? <ToggleRight className="w-4 h-4 text-green-500" /> : <ToggleLeft className="w-4 h-4 text-gray-400" />}
                </button>
                <button onClick={() => deleteMutation.mutate(brand.id)} className="w-8 h-8 rounded-xl bg-gray-50 hover:bg-red-50 hover:text-red-500 flex items-center justify-center transition-all">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}