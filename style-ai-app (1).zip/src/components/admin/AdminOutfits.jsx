import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, ToggleLeft, ToggleRight, SlidersHorizontal, ExternalLink } from "lucide-react";
import OutfitForm from "./OutfitForm";

const categoryColors = {
  shirt: "bg-blue-50 text-blue-600", dress: "bg-pink-50 text-pink-600", pants: "bg-indigo-50 text-indigo-600",
  shoes: "bg-orange-50 text-orange-600", watch: "bg-yellow-50 text-yellow-600", blazer: "bg-gray-100 text-gray-600",
  accessory: "bg-purple-50 text-purple-600", kurta: "bg-rose-50 text-rose-600", saree: "bg-red-50 text-red-600",
  jacket: "bg-cyan-50 text-cyan-600", bag: "bg-lime-50 text-lime-600",
};

export default function AdminOutfits() {
  const qc = useQueryClient();
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [filterCat, setFilterCat] = useState("all");

  const { data: outfits = [], isLoading } = useQuery({
    queryKey: ["outfits"],
    queryFn: () => base44.entities.Outfit.list("-created_date"),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Outfit.delete(id),
    onSuccess: () => qc.invalidateQueries(["outfits"]),
  });

  const toggleMutation = useMutation({
    mutationFn: ({ id, is_active }) => base44.entities.Outfit.update(id, { is_active }),
    onSuccess: () => qc.invalidateQueries(["outfits"]),
  });

  const categories = ["all", ...new Set(outfits.map(o => o.category).filter(Boolean))];
  const filtered = filterCat === "all" ? outfits : outfits.filter(o => o.category === filterCat);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="font-display text-xl font-bold text-[#0C0C12]">Outfits</h2>
          <p className="font-body text-xs text-gray-400 mt-0.5">{outfits.length} items in collection</p>
        </div>
        <button
          onClick={() => { setEditing(null); setShowForm(true); }}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-display font-semibold text-xs text-white bg-purple-600 hover:bg-purple-700 transition-all"
        >
          <Plus className="w-3.5 h-3.5" /> Add Outfit
        </button>
      </div>

      {showForm && (
        <OutfitForm
          outfit={editing}
          onClose={() => { setShowForm(false); setEditing(null); }}
          onSaved={() => { setShowForm(false); setEditing(null); qc.invalidateQueries(["outfits"]); }}
        />
      )}

      {/* Category filter */}
      <div className="flex items-center gap-2 mb-5 overflow-x-auto pb-1">
        <SlidersHorizontal className="w-4 h-4 text-gray-300 flex-shrink-0" />
        {categories.map(cat => (
          <button key={cat} onClick={() => setFilterCat(cat)} className={`flex-shrink-0 px-4 py-1.5 rounded-xl font-display font-semibold text-xs transition-all ${filterCat === cat ? "text-white bg-purple-600" : "bg-white text-gray-400 border border-gray-200 hover:border-purple-200"}`}>
            {cat}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1,2,3,4,5,6].map(i => <div key={i} className="h-32 bg-gray-100 rounded-2xl animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <p className="font-body text-sm text-gray-400">No outfits yet. Add your first item!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(outfit => (
            <div key={outfit.id} className={`vibrant-card rounded-2xl overflow-hidden transition-all ${!outfit.is_active ? "opacity-50" : ""}`}>
              {outfit.image_url && (
                <div className="h-40 overflow-hidden">
                  <img src={outfit.image_url} alt={outfit.name} className="w-full h-full object-cover" />
                </div>
              )}
              <div className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      {outfit.category && (
                        <span className={`font-body text-[10px] font-semibold px-2 py-0.5 rounded-full capitalize ${categoryColors[outfit.category] || "bg-gray-50 text-gray-500"}`}>
                          {outfit.category}
                        </span>
                      )}
                    </div>
                    <p className="font-display font-bold text-xs text-[#0C0C12] leading-snug line-clamp-2">{outfit.name}</p>
                    <p className="font-body text-[10px] text-gray-400 mt-0.5">{outfit.brand} · {outfit.retailer}</p>
                    <p className="font-display text-sm font-bold gradient-text mt-1">{outfit.price}</p>
                    {outfit.shop_url && (
                      <a href={outfit.shop_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-body text-[10px] text-purple-500 hover:underline mt-1">
                        <ExternalLink className="w-3 h-3" /> View Product
                      </a>
                    )}
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <button onClick={() => { setEditing(outfit); setShowForm(true); }} className="w-7 h-7 rounded-xl bg-gray-50 hover:bg-purple-50 hover:text-purple-600 flex items-center justify-center transition-all">
                      <Pencil className="w-3 h-3" />
                    </button>
                    <button onClick={() => toggleMutation.mutate({ id: outfit.id, is_active: !outfit.is_active })} className="w-7 h-7 rounded-xl bg-gray-50 flex items-center justify-center">
                      {outfit.is_active ? <ToggleRight className="w-3.5 h-3.5 text-green-500" /> : <ToggleLeft className="w-3.5 h-3.5 text-gray-400" />}
                    </button>
                    <button onClick={() => deleteMutation.mutate(outfit.id)} className="w-7 h-7 rounded-xl bg-gray-50 hover:bg-red-50 hover:text-red-500 flex items-center justify-center transition-all">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}