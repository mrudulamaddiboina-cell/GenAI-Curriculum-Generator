import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { X, Upload, Loader2 } from "lucide-react";

const defaultOutfit = { name: "", brand: "", price: "", category: "shirt", retailer: "Myntra", shop_url: "", image_url: "", description: "", suitable_for: ["all"], is_active: true };

export default function OutfitForm({ outfit, onClose, onSaved }) {
  const [form, setForm] = useState(outfit || defaultOutfit);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    set("image_url", file_url);
    setUploading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    if (outfit?.id) {
      await base44.entities.Outfit.update(outfit.id, form);
    } else {
      await base44.entities.Outfit.create(form);
    }
    setSaving(false);
    onSaved();
  };

  return (
    <div className="vibrant-card rounded-2xl p-6 mb-6 border-2 border-purple-100">
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-display font-bold text-sm text-[#0C0C12]">{outfit ? "Edit Outfit" : "New Outfit"}</h3>
        <button onClick={onClose} className="w-7 h-7 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center">
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
      <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="sm:col-span-2">
          <label className="font-body text-xs font-medium text-gray-500 mb-1 block">Product Name *</label>
          <input required value={form.name} onChange={e => set("name", e.target.value)} placeholder="e.g. Classic White Oxford Shirt" className="w-full px-4 py-2.5 rounded-xl border border-gray-200 font-body text-sm focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100" />
        </div>
        <div>
          <label className="font-body text-xs font-medium text-gray-500 mb-1 block">Brand *</label>
          <input required value={form.brand} onChange={e => set("brand", e.target.value)} placeholder="e.g. Zara" className="w-full px-4 py-2.5 rounded-xl border border-gray-200 font-body text-sm focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100" />
        </div>
        <div>
          <label className="font-body text-xs font-medium text-gray-500 mb-1 block">Price *</label>
          <input required value={form.price} onChange={e => set("price", e.target.value)} placeholder="₹2,990" className="w-full px-4 py-2.5 rounded-xl border border-gray-200 font-body text-sm focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100" />
        </div>
        <div>
          <label className="font-body text-xs font-medium text-gray-500 mb-1 block">Category *</label>
          <select value={form.category} onChange={e => set("category", e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 font-body text-sm focus:outline-none focus:border-purple-400">
            {["shirt","dress","pants","shoes","watch","blazer","accessory","kurta","saree","jacket","bag"].map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label className="font-body text-xs font-medium text-gray-500 mb-1 block">Retailer</label>
          <select value={form.retailer} onChange={e => set("retailer", e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 font-body text-sm focus:outline-none focus:border-purple-400">
            {["Amazon","Myntra","Zara","Ajio","Nykaa Fashion","Other"].map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="font-body text-xs font-medium text-gray-500 mb-1 block">
            Direct Product URL <span className="text-red-400">*</span>
            <span className="text-gray-400 font-normal ml-1">(link to the exact product page)</span>
          </label>
          <input required type="url" value={form.shop_url} onChange={e => set("shop_url", e.target.value)} placeholder="https://www.myntra.com/product/..." className="w-full px-4 py-2.5 rounded-xl border border-gray-200 font-body text-sm focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100" />
        </div>
        <div className="sm:col-span-2">
          <label className="font-body text-xs font-medium text-gray-500 mb-1 block">Description</label>
          <textarea value={form.description} onChange={e => set("description", e.target.value)} rows={2} placeholder="Short product description..." className="w-full px-4 py-2.5 rounded-xl border border-gray-200 font-body text-sm focus:outline-none focus:border-purple-400 resize-none" />
        </div>

        {/* Image upload */}
        <div className="sm:col-span-2">
          <label className="font-body text-xs font-medium text-gray-500 mb-1 block">Product Image</label>
          <div className="flex items-center gap-4">
            {form.image_url && (
              <img src={form.image_url} alt="preview" className="w-16 h-16 rounded-xl object-cover border border-gray-200" />
            )}
            <label className="flex items-center gap-2 px-4 py-2.5 rounded-xl border-2 border-dashed border-gray-200 hover:border-purple-300 cursor-pointer transition-all">
              {uploading ? <Loader2 className="w-4 h-4 animate-spin text-purple-500" /> : <Upload className="w-4 h-4 text-gray-400" />}
              <span className="font-body text-xs text-gray-500">{uploading ? "Uploading..." : "Upload Image"}</span>
              <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
            </label>
            {form.image_url && !uploading && (
              <button type="button" onClick={() => set("image_url", "")} className="font-body text-xs text-red-400 hover:text-red-600">Remove</button>
            )}
          </div>
        </div>

        <div className="sm:col-span-2 flex items-center gap-3">
          <input type="checkbox" id="active-outfit" checked={form.is_active} onChange={e => set("is_active", e.target.checked)} className="w-4 h-4 accent-purple-500" />
          <label htmlFor="active-outfit" className="font-body text-xs text-gray-500">Active (visible in shop)</label>
        </div>
        <div className="sm:col-span-2 flex gap-3 justify-end pt-2">
          <button type="button" onClick={onClose} className="px-5 py-2.5 rounded-xl font-display text-xs font-semibold border border-gray-200 text-gray-500 hover:bg-gray-50">Cancel</button>
          <button type="submit" disabled={saving || uploading} className="px-6 py-2.5 rounded-xl font-display text-xs font-semibold text-white shimmer-bg hover:opacity-90 disabled:opacity-60">
            {saving ? "Saving..." : outfit ? "Save Changes" : "Add Outfit"}
          </button>
        </div>
      </form>
    </div>
  );
}