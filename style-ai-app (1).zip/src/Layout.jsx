import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Sparkles, Zap } from "lucide-react";
import { base44 } from "@/api/base44Client";

const navLinks = [
  { name: "Home", page: "Home" },
  { name: "Style Analysis", page: "StyleAnalysis" },
  { name: "Shop", page: "Shop" },
  { name: "About", page: "About" },
];

export default function Layout({ children, currentPageName }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="min-h-screen font-body" style={{ backgroundColor: "var(--bg)" }}>
      {/* Top color bar */}
      <div className="fixed top-0 left-0 right-0 h-1 shimmer-bg z-[60]" />

      {/* Navigation */}
      <nav className={`fixed top-1 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? "top-2" : "top-4"}`}>
        <div className={`mx-4 sm:mx-8 rounded-2xl px-6 py-3 transition-all duration-500 ${
          scrolled
            ? "bg-white/90 backdrop-blur-xl shadow-[0_4px_32px_rgba(123,79,212,0.15)]"
            : "bg-white/70 backdrop-blur-md"
        }`}>
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to={createPageUrl("Home")} className="flex items-center gap-2 group">
              <div className="w-7 h-7 rounded-lg shimmer-bg flex items-center justify-center">
                <Zap className="w-3.5 h-3.5 text-white" fill="white" />
              </div>
              <span className="font-display font-800 text-lg tracking-tight">
                <span className="gradient-text">Style</span>
                <span className="text-[#0C0C12]">AI</span>
              </span>
            </Link>

            {/* Desktop nav */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={createPageUrl(link.page)}
                  className={`relative px-4 py-2 rounded-xl font-body text-sm font-medium transition-all duration-300 ${
                    currentPageName === link.page
                      ? "text-[#7B4FD4]"
                      : "text-gray-500 hover:text-gray-800 hover:bg-gray-50"
                  }`}
                >
                  {currentPageName === link.page && (
                    <motion.div
                      layoutId="nav-active"
                      className="absolute inset-0 bg-purple-50 rounded-xl"
                    />
                  )}
                  <span className="relative z-10">{link.name}</span>
                </Link>
              ))}
            </div>

            {/* CTA + Mobile button */}
            <div className="flex items-center gap-3">
              
              <Link
                to={createPageUrl("StyleAnalysis")}
                className="hidden sm:flex items-center gap-2 px-5 py-2 rounded-xl font-display font-semibold text-xs tracking-wide text-white bg-purple-600 hover:bg-purple-700 transition-all shadow-[0_4px_15px_rgba(123,79,212,0.35)]"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Get Styled
              </Link>
              <button
                className="md:hidden w-9 h-9 rounded-xl bg-gray-100 flex items-center justify-center"
                onClick={() => setMenuOpen(true)}
              >
                <Menu className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            className="fixed inset-0 z-[100]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="absolute inset-0 bg-[#0C0C12]" />
            {/* Colored blobs */}
            <div className="absolute top-0 left-0 w-80 h-80 rounded-full opacity-20 blob"
              style={{ background: "var(--magenta)", filter: "blur(80px)", top: "10%", left: "-10%" }} />
            <div className="absolute w-64 h-64 rounded-full opacity-20 blob-delay"
              style={{ background: "var(--electric)", filter: "blur(80px)", bottom: "10%", right: "-10%" }} />

            <button
              className="absolute top-8 right-8 w-10 h-10 rounded-xl border border-white/20 flex items-center justify-center z-10 text-white"
              onClick={() => setMenuOpen(false)}
            >
              <X className="w-5 h-5" />
            </button>

            <div className="relative z-10 flex flex-col items-start justify-center h-full px-10 gap-6">
              {navLinks.map((link, i) => (
                <motion.div
                  key={link.name}
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.08 }}
                >
                  <Link
                    to={createPageUrl(link.page)}
                    onClick={() => setMenuOpen(false)}
                    className="font-display text-5xl font-bold text-white/80 hover:text-white transition-colors"
                  >
                    {link.name}
                  </Link>
                </motion.div>
              ))}
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
                <Link
                  to={createPageUrl("StyleAnalysis")}
                  onClick={() => setMenuOpen(false)}
                  className="mt-4 inline-flex items-center gap-2 px-6 py-3 rounded-xl font-display font-semibold text-sm text-white bg-purple-600 hover:bg-purple-700 transition-all"
                >
                  <Sparkles className="w-4 h-4" />
                  Get Styled Free
                </Link>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Page content */}
      <main className="pt-20">{children}</main>
    </div>
  );
}