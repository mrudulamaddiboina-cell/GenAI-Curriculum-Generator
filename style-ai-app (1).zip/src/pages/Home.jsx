import React from "react";
import HeroSection from "@/components/style-ai/HeroSection";
import FeatureCards from "@/components/style-ai/FeatureCards";
import HowItWorks from "@/components/style-ai/HowItWorks";
import FooterSection from "@/components/style-ai/FooterSection";

export default function Home() {
  return (
    <div>
      <HeroSection />
      <FeatureCards />
      <HowItWorks />
      <FooterSection />
    </div>
  );
}