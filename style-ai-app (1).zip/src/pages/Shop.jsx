import React, { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { SlidersHorizontal, Search } from "lucide-react";
import ShopCard from "@/components/style-ai/ShopCard";
import FooterSection from "@/components/style-ai/FooterSection";

export default function Shop() {
  const urlParams = new URLSearchParams(window.location.search);
  const analysisId = urlParams.get("id");
  const [activeFilter, setActiveFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("newest");

  const { data: analysis } = useQuery({
    queryKey: ["analysis-shop", analysisId],
    queryFn: async () => {
      if (!analysisId) return null;
      const items = await base44.entities.StyleAnalysis.filter({ id: analysisId });
      return items?.[0] || null;
    },
    enabled: !!analysisId,
  });

  const { data: adminOutfits = [] } = useQuery({
    queryKey: ["outfits-shop"],
    queryFn: () => base44.entities.Outfit.filter({ is_active: true }, "-created_date"),
  });

  // Use admin-curated outfits if available, else fall back to AI analysis items
  const shopItems = adminOutfits.length > 0
    ? adminOutfits
    : (analysis?.shopping_items || []);

  const categories = ["all", ...new Set(shopItems.map(i => i.category?.toLowerCase()).filter(Boolean))];

  const parsePrice = (p) => {
    if (!p) return 0;
    return parseFloat(String(p).replace(/[^0-9.]/g, "")) || 0;
  };

  const filteredItems = shopItems
    .filter(i => activeFilter === "all" || i.category?.toLowerCase() === activeFilter)
    .filter(i => {
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return i.name?.toLowerCase().includes(q) || i.brand?.toLowerCase().includes(q);
    })
    .sort((a, b) => {
      if (sortBy === "price-asc") return parsePrice(a.price) - parsePrice(b.price);
      if (sortBy === "price-desc") return parsePrice(b.price) - parsePrice(a.price);
      return 0; // newest: keep original order (fetched as -created_date)
    });

  return (
    <div className="min-h-screen" style={{ backgroundColor: "var(--bg)" }}>
      {/* Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute w-96 h-96 blob opacity-10" style={{ background: "var(--mint)", filter: "blur(120px)", top: "-10%", left: "-10%" }} />
        <div className="absolute w-80 h-80 blob-delay opacity-10" style={{ background: "var(--magenta)", filter: "blur(100px)", bottom: "10%", right: "-5%" }} />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-6 py-16">
        {/* Header */}
        <motion.div className="text-center mb-12" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <span className="inline-block font-body text-xs font-semibold tracking-widest uppercase text-purple-500 bg-purple-50 px-4 py-1.5 rounded-full mb-4">
            Curated For You
          </span>
          <h1 className="font-display text-4xl sm:text-5xl font-bold mb-3">
            <span className="gradient-text">Shop</span> Your Style
          </h1>
          <p className="font-body text-sm text-gray-400 max-w-md mx-auto">
            {analysis
              ? "Personalized picks based on your style analysis from India's top retailers."
              : "Browse our curated fashion collection from India's top retailers."}
          </p>
        </motion.div>

        {/* Skin tone badge */}
        {analysis && (
          <motion.div className="flex items-center justify-center gap-3 mb-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
            <div className="w-5 h-5 rounded-full shadow ring-2 ring-white" style={{ backgroundColor: analysis.skin_tone_hex }} />
            <p className="font-body text-xs text-gray-500">
              Styled for <span className="capitalize font-semibold text-gray-700">{analysis.skin_tone_category}</span> skin
              {analysis.undertone && <span> · {analysis.undertone} undertone</span>}
            </p>
          </motion.div>
        )}

        {/* Search + Sort */}
        <motion.div
          className="flex flex-col sm:flex-row gap-3 mb-5"
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
        >
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by name or brand..."
              className="w-full pl-11 pr-4 py-2.5 rounded-xl border border-gray-200 bg-white font-body text-sm text-gray-700 placeholder:text-gray-400 focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100 transition-all"
            />
          </div>
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value)}
            className="px-4 py-2.5 rounded-xl border border-gray-200 bg-white font-body text-sm text-gray-600 focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100 transition-all cursor-pointer"
          >
            <option value="newest">Newest Arrivals</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
          </select>
        </motion.div>

        {/* Category Filters */}
        <motion.div
          className="flex items-center gap-2 mb-8 overflow-x-auto pb-1"
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
        >
          <SlidersHorizontal className="w-4 h-4 text-gray-300 flex-shrink-0" />
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveFilter(cat)}
              className={`flex-shrink-0 px-4 py-2 rounded-xl font-display font-semibold text-xs transition-all duration-300 ${
                activeFilter === cat
                  ? "text-white bg-purple-600 shadow-[0_4px_15px_rgba(123,79,212,0.3)]"
                  : "bg-white text-gray-500 border border-gray-200 hover:border-purple-200 hover:text-purple-600"
              }`}
            >
              {cat}
            </button>
          ))}
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
          {filteredItems.map((item, i) => (
            <ShopCard key={i} item={item} index={i} />
          ))}
        </div>

        {/* CTA if no analysis */}
        {!analysis && (
          <motion.div className="text-center mt-16" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
            <p className="font-body text-sm text-gray-400 mb-4">Want picks tailored to your skin tone?</p>
            <Link to={createPageUrl("StyleAnalysis")}>
              <button className="px-8 py-3.5 rounded-2xl font-display font-semibold text-sm text-white bg-purple-600 hover:bg-purple-700 transition-all shadow-[0_4px_20px_rgba(123,79,212,0.35)]">
                Get Your Style Analysis
              </button>
            </Link>
          </motion.div>
        )}
      </div>
      <FooterSection />
    </div>
  );
}