import React, { useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import UploadPortal from "@/components/style-ai/UploadPortal";
import AnalyzingState from "@/components/style-ai/AnalyzingState";
import FooterSection from "@/components/style-ai/FooterSection";

export default function StyleAnalysis() {
  const [state, setState] = useState("upload");
  const [photoUrl, setPhotoUrl] = useState(null);
  const navigate = useNavigate();

  const handleAnalysisStart = async ({ photoUrl: url, gender }) => {
    setPhotoUrl(url);
    setState("analyzing");

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an expert AI fashion stylist. Analyze the person in this photo and provide comprehensive styling recommendations.

The user has selected gender: ${gender}.

Analyze the photo to determine:
1. Skin tone category (fair, medium, olive, or deep)
2. Skin undertone (warm, cool, or neutral)
3. Approximate skin RGB color values
4. Approximate skin hex color

Then provide:
- A detailed explanation of why certain styles suit this skin tone
- Outfit recommendations across categories (formal, business, casual, party) with specific items
- A personalized color palette with primary (3 colors), secondary (3 colors), and accent (2 colors) (with hex values)
- Accessory recommendations (watches, necklaces, earrings, bracelets)
- Hairstyle recommendations (3-4 styles)
- Shopping items with specific product names, brands, estimated prices in INR, categories, and retailer (Amazon, Myntra, or Zara)

Be specific, trendy, and fashion-forward. Consider current 2026 fashion trends.`,
      file_urls: [url],
      response_json_schema: {
        type: "object",
        properties: {
          skin_tone_category: { type: "string", enum: ["fair", "medium", "olive", "deep"] },
          skin_tone_rgb: { type: "string" },
          skin_tone_hex: { type: "string" },
          undertone: { type: "string", enum: ["warm", "cool", "neutral"] },
          analysis_explanation: { type: "string" },
          outfit_recommendations: { type: "array", items: { type: "object", properties: { category: { type: "string" }, name: { type: "string" }, description: { type: "string" }, type: { type: "string" } } } },
          color_palette: { type: "array", items: { type: "object", properties: { name: { type: "string" }, hex: { type: "string" }, type: { type: "string", enum: ["primary", "secondary", "accent"] } } } },
          accessories: { type: "array", items: { type: "object", properties: { type: { type: "string" }, name: { type: "string" }, description: { type: "string" } } } },
          hairstyles: { type: "array", items: { type: "object", properties: { name: { type: "string" }, description: { type: "string" } } } },
          shopping_items: { type: "array", items: { type: "object", properties: { name: { type: "string" }, brand: { type: "string" }, price: { type: "string" }, category: { type: "string" }, retailer: { type: "string" }, shop_url: { type: "string" } } } }
        }
      }
    });

    const savedAnalysis = await base44.entities.StyleAnalysis.create({
      photo_url: url,
      gender,
      skin_tone_category: result.skin_tone_category,
      skin_tone_rgb: result.skin_tone_rgb,
      skin_tone_hex: result.skin_tone_hex,
      undertone: result.undertone,
      analysis_explanation: result.analysis_explanation,
      outfit_recommendations: result.outfit_recommendations,
      color_palette: result.color_palette,
      accessories: result.accessories,
      hairstyles: result.hairstyles,
      shopping_items: result.shopping_items,
    });

    navigate(createPageUrl("Recommendations") + `?id=${savedAnalysis.id}`);
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: "var(--bg)" }}>
      {/* Background blobs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute w-96 h-96 blob opacity-15" style={{ background: "var(--magenta)", filter: "blur(120px)", top: "5%", right: "-5%" }} />
        <div className="absolute w-80 h-80 blob-delay opacity-10" style={{ background: "var(--electric)", filter: "blur(100px)", bottom: "10%", left: "-5%" }} />
      </div>

      <div className="relative z-10 max-w-3xl mx-auto px-6 py-16">
        <motion.div
          className="text-center mb-10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <span className="inline-block font-body text-xs font-semibold tracking-widest uppercase text-purple-500 bg-purple-50 px-4 py-1.5 rounded-full mb-4">
            Style Analysis
          </span>
          <h1 className="font-display text-4xl sm:text-5xl font-bold mb-3">
            <span className="gradient-text">Discover</span> Your Style
          </h1>
          <p className="font-body text-base text-gray-400 max-w-md mx-auto">
            Upload a clear photo and let our AI build your complete personal style profile.
          </p>
        </motion.div>

        {state === "upload" && <UploadPortal onAnalysisStart={handleAnalysisStart} />}
        {state === "analyzing" && <AnalyzingState photoUrl={photoUrl} />}
      </div>
      <FooterSection />
    </div>
  );
}