import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { ShoppingBag, ArrowRight, RotateCcw } from "lucide-react";
import SkinToneResult from "@/components/style-ai/SkinToneResult";
import ColorPalette from "@/components/style-ai/ColorPalette";
import OutfitRecommendations from "@/components/style-ai/OutfitRecommendations";
import AccessoriesSection from "@/components/style-ai/AccessoriesSection";
import HairstyleSection from "@/components/style-ai/HairstyleSection";
import CuratedOutfits from "@/components/style-ai/CuratedOutfits";
import FooterSection from "@/components/style-ai/FooterSection";

export default function Recommendations() {
  const urlParams = new URLSearchParams(window.location.search);
  const analysisId = urlParams.get("id");

  const { data: analysis, isLoading } = useQuery({
    queryKey: ["analysis", analysisId],
    queryFn: async () => {
      if (!analysisId) return null;
      const items = await base44.entities.StyleAnalysis.filter({ id: analysisId });
      return items?.[0] || null;
    },
    enabled: !!analysisId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: "var(--bg)" }}>
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl shimmer-bg mx-auto mb-4 pulse-ring" />
          <p className="font-display text-lg font-semibold text-gray-500">Loading your profile...</p>
        </div>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6" style={{ backgroundColor: "var(--bg)" }}>
        <div className="text-center">
          <p className="font-display text-3xl font-bold mb-4">No Analysis Found</p>
          <p className="font-body text-sm text-gray-400 mb-8 max-w-sm mx-auto">
            Start by uploading a photo to get your personalized style recommendations.
          </p>
          <Link to={createPageUrl("StyleAnalysis")}>
            <button className="px-8 py-3.5 rounded-2xl font-display font-semibold text-sm text-white bg-purple-600 hover:bg-purple-700 transition-all">
              Start Analysis
            </button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: "var(--bg)" }}>
      {/* Header blob */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute w-96 h-96 blob opacity-10" style={{ background: "var(--purple)", filter: "blur(120px)", top: "0%", right: "0%" }} />
      </div>

      <div className="relative z-10 max-w-3xl mx-auto px-6 py-16">
        <motion.div className="text-center mb-8" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <span className="inline-block font-body text-xs font-semibold tracking-widest uppercase text-purple-500 bg-purple-50 px-4 py-1.5 rounded-full mb-4">
            Your Results
          </span>
          <h1 className="font-display text-4xl sm:text-5xl font-bold mb-3">
            Your <span className="gradient-text">Style Profile</span>
          </h1>
          <p className="font-body text-sm text-gray-400">AI-crafted recommendations for your unique beauty.</p>
        </motion.div>

        {/* Photo */}
        {analysis.photo_url && (
          <motion.div
            className="flex justify-center mb-8"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <div className="w-24 h-24 rounded-full overflow-hidden ring-4 ring-white shadow-xl">
              <img src={analysis.photo_url} alt="User" className="w-full h-full object-cover" />
            </div>
          </motion.div>
        )}

        {/* Results */}
        <div className="space-y-5">
          <SkinToneResult analysis={analysis} />
          <ColorPalette colors={analysis.color_palette} />
          <OutfitRecommendations outfits={analysis.outfit_recommendations} />
          <AccessoriesSection accessories={analysis.accessories} />
          <HairstyleSection hairstyles={analysis.hairstyles} />
          <CuratedOutfits analysis={analysis} analysisId={analysisId} />
        </div>

        {/* Actions */}
        <motion.div
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Link to={createPageUrl("Shop") + `?id=${analysisId}`}>
            <button className="flex items-center gap-2 px-8 py-3.5 rounded-2xl font-display font-semibold text-sm text-white bg-purple-600 hover:bg-purple-700 transition-all shadow-[0_4px_20px_rgba(123,79,212,0.35)]">
              <ShoppingBag className="w-4 h-4" />
              Shop Your Style
              <ArrowRight className="w-4 h-4" />
            </button>
          </Link>
          <Link to={createPageUrl("StyleAnalysis")}>
            <button className="flex items-center gap-2 px-8 py-3.5 rounded-2xl font-display font-semibold text-sm border-2 border-gray-200 hover:border-purple-300 text-gray-600 hover:text-purple-600 transition-all bg-white">
              <RotateCcw className="w-4 h-4" />
              New Analysis
            </button>
          </Link>
        </motion.div>
      </div>
      <FooterSection />
    </div>
  );
}