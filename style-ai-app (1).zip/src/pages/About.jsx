import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Brain, Camera, Palette, ShoppingBag, ArrowRight, Zap } from "lucide-react";
import FooterSection from "@/components/style-ai/FooterSection";

const values = [
  { icon: Brain, title: "AI-Powered Intelligence", desc: "Our AI understands the intersection of skin science, color theory, and fashion trends for truly personalized results.", gradient: "var(--gradient-card-1)" },
  { icon: Palette, title: "Color Science", desc: "Advanced chromatic analysis identifies your exact skin tone, undertone, and the colors that make you radiate confidence.", gradient: "var(--gradient-card-2)" },
  { icon: ShoppingBag, title: "Curated Fashion", desc: "Every recommendation is verified against current trends from India's top retailers including Amazon, Myntra, and Zara.", gradient: "var(--gradient-card-3)" },
  { icon: Camera, title: "Privacy First", desc: "Your photos are processed securely and never shared. Fashion intelligence without compromise.", gradient: "var(--gradient-card-4)" },
];

const tech = [
  { name: "AI Model", detail: "Advanced LLM for skin tone analysis & fashion intelligence" },
  { name: "Image Processing", detail: "Computer vision for precise complexion detection" },
  { name: "Fashion Database", detail: "Curated collection from top Indian retailers" },
  { name: "Color Theory Engine", detail: "Algorithmic color matching based on skin science" },
];

export default function About() {
  return (
    <div className="min-h-screen" style={{ backgroundColor: "var(--bg)" }}>
      {/* Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute w-96 h-96 blob opacity-10" style={{ background: "var(--purple)", filter: "blur(120px)", top: "5%", right: "-5%" }} />
        <div className="absolute w-80 h-80 blob-delay opacity-10" style={{ background: "var(--electric)", filter: "blur(100px)", bottom: "10%", left: "-5%" }} />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 py-16">
        {/* Header */}
        <motion.div className="text-center mb-20" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <span className="inline-block font-body text-xs font-semibold tracking-widest uppercase text-purple-500 bg-purple-50 px-4 py-1.5 rounded-full mb-4">
            About Us
          </span>
          <h1 className="font-display text-5xl sm:text-6xl font-bold mb-6 leading-tight">
            The Future of<br />
            <span className="gradient-text">Personal Style</span>
          </h1>
          <p className="font-body text-base text-gray-500 max-w-2xl mx-auto leading-relaxed">
            Style AI is an intelligent styling platform that analyzes your unique skin tone and provides expert fashion
            guidance — helping you choose the best outfits, accessories, and colors that truly complement your natural beauty.
          </p>
        </motion.div>

        {/* Quote */}
        <motion.div
          className="vibrant-card rounded-3xl p-10 sm:p-14 text-center mb-16 relative overflow-hidden"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div className="absolute inset-0 shimmer-bg opacity-5" />
          <div className="w-12 h-12 rounded-2xl shimmer-bg flex items-center justify-center mx-auto mb-6">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <p className="font-editorial text-2xl sm:text-3xl italic leading-relaxed text-gray-700 relative z-10">
            "We believe everyone deserves to feel confident in what they wear. Our mission is to
            democratize personal styling through the power of AI."
          </p>
        </motion.div>

        {/* Values */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-16">
          {values.map((v, i) => (
            <motion.div
              key={v.title}
              className="group relative rounded-3xl overflow-hidden cursor-default"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -4, transition: { duration: 0.25 } }}
            >
              <div className="absolute inset-0 opacity-90" style={{ background: v.gradient }} />
              <div className="relative z-10 p-8">
                <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center mb-5">
                  <v.icon className="w-5 h-5 text-white" />
                </div>
                <h3 className="font-display text-white font-bold text-xl mb-2">{v.title}</h3>
                <p className="font-body text-white/75 text-sm leading-relaxed">{v.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Tech */}
        <motion.div className="mb-16" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <h2 className="font-display text-3xl font-bold text-center mb-8">
            Powered <span className="gradient-text">By</span>
          </h2>
          <div className="space-y-3">
            {tech.map((t, i) => (
              <motion.div
                key={t.name}
                className="vibrant-card rounded-2xl px-6 py-4 flex items-center justify-between"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <div>
                  <p className="font-display text-sm font-semibold text-[#0C0C12]">{t.name}</p>
                  <p className="font-body text-xs text-gray-400">{t.detail}</p>
                </div>
                <div className="w-8 h-8 rounded-xl shimmer-bg flex-shrink-0" />
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div className="text-center" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <Link to={createPageUrl("StyleAnalysis")}>
            <button className="group inline-flex items-center gap-3 px-10 py-4 rounded-2xl font-display font-bold text-sm text-white shimmer-bg hover:opacity-90 hover:shadow-[0_8px_30px_rgba(255,60,172,0.35)] transition-all">
              Start Your Analysis
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </Link>
        </motion.div>
      </div>

      <FooterSection />
    </div>
  );
}