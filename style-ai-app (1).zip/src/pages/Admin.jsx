import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { ShoppingBag, Tag, Lock, LayoutDashboard } from "lucide-react";
import AdminBrands from "@/components/admin/AdminBrands";
import AdminOutfits from "@/components/admin/AdminOutfits";

const tabs = [
  { id: "outfits", label: "Outfits", icon: ShoppingBag },
  { id: "brands", label: "Brands", icon: Tag },
];

export default function Admin() {
  const [activeTab, setActiveTab] = useState("outfits");
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.auth.me().then(u => { setUser(u); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: "var(--bg)" }}>
        <div className="w-10 h-10 rounded-2xl shimmer-bg animate-pulse" />
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center px-6" style={{ backgroundColor: "var(--bg)" }}>
        <div className="text-center max-w-sm">
          <div className="w-16 h-16 rounded-2xl bg-red-50 flex items-center justify-center mx-auto mb-5">
            <Lock className="w-8 h-8 text-red-400" />
          </div>
          <h1 className="font-display text-2xl font-bold text-[#0C0C12] mb-2">Admin Only</h1>
          <p className="font-body text-sm text-gray-400">You need admin privileges to access this portal.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: "var(--bg)" }}>
      {/* Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute w-96 h-96 blob opacity-10" style={{ background: "var(--purple)", filter: "blur(120px)", top: "0%", right: "0%" }} />
        <div className="absolute w-80 h-80 blob-delay opacity-8" style={{ background: "var(--mint)", filter: "blur(100px)", bottom: "10%", left: "-5%" }} />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 py-16">
        {/* Header */}
        <motion.div className="mb-10" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-9 h-9 rounded-xl shimmer-bg flex items-center justify-center">
              <LayoutDashboard className="w-4 h-4 text-white" />
            </div>
            <span className="font-body text-xs font-semibold tracking-widest uppercase text-purple-500 bg-purple-50 px-3 py-1 rounded-full">Admin Portal</span>
          </div>
          <h1 className="font-display text-4xl font-bold text-[#0C0C12]">
            Manage <span className="gradient-text">Collection</span>
          </h1>
          <p className="font-body text-sm text-gray-400 mt-1">Add and manage brands and outfits shown in the shop.</p>
        </motion.div>

        {/* Tabs */}
        <motion.div className="flex gap-2 mb-8 p-1.5 bg-white rounded-2xl border border-gray-100 w-fit shadow-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}>
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-display font-semibold text-xs transition-all duration-300 ${
                activeTab === tab.id ? "text-white bg-purple-600 shadow-[0_4px_15px_rgba(123,79,212,0.3)]" : "text-gray-500 hover:text-gray-700"
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          ))}
        </motion.div>

        {/* Content */}
        <motion.div key={activeTab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2 }}>
          {activeTab === "brands" && <AdminBrands />}
          {activeTab === "outfits" && <AdminOutfits />}
        </motion.div>
      </div>
    </div>
  );
}